# TSK-000-36-clone-of-internee.pk
It was a task to clone internee.pk website using html, css and js
